let imageSource = '/Renders/InFrontOfGate.png';
let collisionBox = {
    x: 0.0,
    y: 0.0,
    w: 0.0,
    h: 0.0,
    spriteSheetSource: '/Renders/Animations/GateOpen.png',
    spriteSheet: new Image(),
    spriteAmount: 20
};