let imageSource = '/Renders/FarFromGate.png';
let collisionBox = {
    x: 0.38,
    y: 0.44,
    w: 0.13,
    h: 0.24,
    spriteSheetSource: '/Renders/Animations/GateOpen.png',
    spriteSheet: new Image(),
    spriteAmount: 20
};