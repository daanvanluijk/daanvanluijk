let canvas;
let ctx;
let canvasW;
let canvasH;
let image;
let imageW;
let imageH;
let mouseX;
let mouseY;
let spriteW = 640;
let spriteH = 480;

function init() {
    console.log("INITIALIZING");

    collisionBox.spriteSheet.src = collisionBox.spriteSheetSource;
    image = new Image();
    image.src = imageSource;
    imageW = image.width;
    imageH = image.height;
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext('2d');

    console.log(canvas);
    console.log(ctx);
    console.log("INITIALIZING FINISHED");

    draw();
}

function draw() {
    console.log("DRAWING");

    //image.onload = null;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvasW = canvas.width;
    canvasH = canvas.height;

    let newH = (imageH * (canvasW / imageW))
    let difference = newH - canvasH;
    ctx.drawImage(image, 0, -difference / 2, canvasW, newH);

    //ctx.fillStyle = "#FF000000";
    //ctx.fillRect(canvasW * collisionBox.x, newH * collisionBox.y - difference / 2,
    //    canvasW * collisionBox.w, newH * collisionBox.h);
}

function onMouseClick() {
    let newH = (imageH * (canvasW / imageW))
    let difference = newH - canvasH;
    if (mouseX > canvasW * collisionBox.x && mouseX < canvasW * collisionBox.x + canvasW * collisionBox.x
        && mouseY > newH * collisionBox.y - difference / 2 && mouseY < (newH * collisionBox.y - difference / 2) + newH * collisionBox.h) {
        playExitAnimation(collisionBox).then(r => console.log("done"));
    }
}

async function playExitAnimation(cb) {
    let newH = (imageH * (canvasW / imageW))
    let difference = newH - canvasH;
    console.log(cb.spriteAmount);
    for (let i = 0; i < cb.spriteAmount; i++) {
        ctx.drawImage(cb.spriteSheet, i * spriteW, 0, spriteW, spriteH, 0, -difference / 2, canvasW, newH);
        await sleep(83);
        console.log(i * spriteW);
    }
    window.location.href = "inFrontOfGate.html";
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

document.addEventListener('mousemove', (event) => {
    mouseX = event.clientX;
    mouseY = event.clientY;
});
window.addEventListener('resize', draw);
window.addEventListener('click', onMouseClick);

init();
image.onload = draw;
console.log(image);